from pathlib import Path
import re
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = Path('/home/user/artykuly_psychodynamiczne')
OUT.mkdir(parents=True, exist_ok=True)

articles = [
{
    'number': 1,
    'filename': '01-dlaczego-wybieram-podobnych-partnerow.docx',
    'seo_title': 'Dlaczego wybieram podobnych partnerów? Schematy relacji',
    'meta': 'Dlaczego kolejne związki bywają do siebie podobne? Poznaj nieświadome schematy relacyjne z perspektywy psychoterapii psychodynamicznej we Wrocławiu.',
    'slug': '/blog/dlaczego-wybieram-podobnych-partnerow/',
    'primary': 'dlaczego wybieram podobnych partnerów',
    'secondary': 'schematy w związkach; nieświadome wzorce relacyjne; psychoterapia psychodynamiczna Wrocław Gaj',
    'h1': 'Dlaczego ciągle wybieram podobnych partnerów?',
    'lead': 'Zmieniają się imiona, okoliczności i początek znajomości, a jednak po pewnym czasie relacja zaczyna przypominać poprzednią. Pojawia się podobny dystans, lęk przed odrzuceniem, nadmierna odpowiedzialność albo poczucie, że ponownie trzeba zabiegać o czyjąś uwagę. Z perspektywy psychodynamicznej nie musi to świadczyć o „złym guście” czy braku rozsądku. Często jest śladem nieświadomego wzorca relacyjnego — sposobu przeżywania bliskości, który powstał wcześniej i nadal organizuje wybory, oczekiwania oraz reakcje.',
    'sections': [
        ('Znajome nie zawsze oznacza dobre', [
            'W relacjach człowiek nie kieruje się wyłącznie świadomą listą cech pożądanego partnera. Znaczenie ma również to, co emocjonalnie znajome. Jeśli bliskość w ważnych wczesnych relacjach łączyła się z niepewnością, krytyką, koniecznością dopasowania albo walką o uwagę, podobna dynamika może w dorosłości wydawać się zaskakująco naturalna. Nie dlatego, że cierpienie jest pożądane, lecz dlatego, że psychika łatwiej rozpoznaje układ, którego reguły już zna.',
            'To, co stabilne i dostępne, może początkowo wydawać się mało intensywne. Z kolei dystans drugiej osoby może uruchamiać silne pragnienie bliskości, interpretowane jako wyjątkowa chemia. Sama intensywność uczucia nie przesądza więc o jakości relacji.'
        ]),
        ('Wewnętrzna mapa relacji', [
            'Podejście psychodynamiczne zakłada, że doświadczenia z ważnymi osobami zostają uwewnętrznione. Powstaje swoista mapa: czego można oczekiwać od innych, kim trzeba być, aby zasłużyć na uwagę, oraz co stanie się po ujawnieniu potrzeb. Mapa ta działa przeważnie poza świadomą kontrolą. Wpływa nie tylko na wybór partnera, ale też na interpretowanie jego zachowań.',
            'Neutralne milczenie może zostać odczytane jako odrzucenie, prośba jako krytyka, a różnica zdań jako zapowiedź rozpadu związku. Reakcja dotyczy wtedy zarówno bieżącej sytuacji, jak i wcześniejszych emocjonalnych znaczeń, które sytuacja nieświadomie przywołała.'
        ]),
        ('Dlaczego wzorzec się powtarza?', [
            'Powtarzanie nie jest świadomą decyzją. Bywa próbą opanowania dawnego doświadczenia i doprowadzenia go do innego zakończenia. Osoba, która długo zabiegała o niedostępnego opiekuna, może ponownie angażować się w relację z kimś zdystansowanym, z nadzieją, że tym razem zostanie wybrana. Taka nadzieja rzadko przybiera formę wyraźnej myśli; częściej ujawnia się jako silne przyciąganie, uporczywe czekanie lub trudność w odejściu.',
            'Nie zawsze powtarza się typ partnera. Czasem powtarzana jest rola: ratownika, osoby podporządkowanej, kontrolującej albo tej, która pierwsza wycofuje się z obawy przed porzuceniem. Partnerzy współtworzą dynamikę, ale odpowiedzialność za przemoc, manipulację czy przekraczanie granic zawsze pozostaje po stronie osoby, która się ich dopuszcza.'
        ]),
        ('Co może pomóc zauważyć schemat?', [
            'Warto przyglądać się nie tylko temu, jacy byli kolejni partnerzy, lecz także własnej pozycji w relacji. Znaczące bywają momenty najsilniejszego przyciągania, sytuacje uruchamiające lęk oraz powtarzalny sposób reagowania na dystans, konflikt i troskę. Pomocne pytania dotyczą tego, kiedy pojawia się poczucie, że trzeba zasłużyć na bliskość, oraz jakie zachowania drugiej osoby są usprawiedliwiane mimo własnego dyskomfortu.',
            'Taka obserwacja nie ma służyć samooskarżaniu. Schemat rozwijał się zwykle jako sposób radzenia sobie i dlatego zasługuje najpierw na zrozumienie. Istotne pozostaje także sprawdzanie faktów: nie każda obawa jest projekcją, a nie każda trudna relacja wynika wyłącznie z osobistej historii.'
        ]),
        ('Jak psychoterapia pomaga zobaczyć niewidoczne?', [
            'W psychoterapii psychodynamicznej analizuje się nie tylko historię związków, lecz także emocje, fantazje, uniki i oczekiwania pojawiające się w bieżących relacjach. Szczególne znaczenie ma relacja terapeutyczna. Również w niej mogą ujawnić się obawy, że potrzeby okażą się nadmierne, różnica zdań zakończy kontakt albo akceptację trzeba sobie wypracować.',
            'Terapeuta nie ocenia tych reakcji jako błędnych. Pomaga je nazywać, łączyć z kontekstem i odróżniać przeszłe doświadczenie od aktualnej sytuacji. Z czasem automatyczny wzorzec staje się czymś, co można rozpoznać przed działaniem, a nie dopiero po kolejnym rozczarowaniu.'
        ]),
        ('Zmiana nie polega na znalezieniu „idealnej” osoby', [
            'Celem terapii nie jest stworzenie bezbłędnego algorytmu wyboru partnera. Chodzi o większą swobodę: zdolność zauważania własnych potrzeb, tolerowania bliskości bez utraty siebie, przyjmowania granic drugiej osoby i odróżniania konfliktu od zagrożenia. Ważnym sygnałem zmiany bywa także to, że spokój przestaje być mylony z obojętnością, a napięcie — z miłością.',
            'Psychoterapia psychodynamiczna we Wrocławiu, na Gaju, lub prowadzona online może tworzyć warunki do takiej pracy, ale tempo zmiany jest indywidualne. Rozpoznanie schematu stanowi początek. Trwalsza zmiana pojawia się wtedy, gdy nowe rozumienie zostaje również emocjonalnie przeżyte i wypróbowane w relacji.'
        ]),
    ],
    'faq': [
        ('Czy wybieranie podobnych partnerów oznacza zaburzenie?', 'Nie. Powtarzalne wzorce występują u wielu osób. O problemie warto myśleć wtedy, gdy regularnie prowadzą do cierpienia, ograniczają wybór lub utrudniają tworzenie bezpiecznej bliskości.'),
        ('Czy za każdy schemat odpowiada dzieciństwo?', 'Nie. Znaczenie mają także późniejsze związki, temperament, aktualne warunki życia i doświadczenia społeczne. Terapia bada indywidualną historię zamiast zakładać jedną przyczynę.'),
        ('Czy samo rozpoznanie wzorca wystarczy, aby go zmienić?', 'Zwykle jest konieczne, ale nie zawsze wystarczające. Schemat obejmuje emocje i automatyczne sposoby reagowania, dlatego zmiana wymaga czasu oraz wielokrotnego przepracowania.'),
    ],
    'links': [
        ('Artykuł 2', '„Wiem, skąd to się bierze, ale nadal tak robię” — dlaczego sama świadomość nie wystarcza?', 'sama świadomość nie zawsze zmienia schemat'),
        ('Artykuł 3', 'Co dzieje się między pacjentem a terapeutą?', 'relacja terapeutyczna'),
        ('Strona usługowa', 'Psychoterapia psychodynamiczna Wrocław – Gaj', 'psychoterapia psychodynamiczna we Wrocławiu na Gaju'),
    ],
},
{
    'number': 2,
    'filename': '02-dlaczego-sama-swiadomosc-nie-wystarcza.docx',
    'seo_title': 'Dlaczego sama świadomość problemu nie wystarcza?',
    'meta': 'Rozumienie przyczyn to ważny krok, ale trwała zmiana wymaga emocjonalnego przepracowania. Wyjaśnia to psychoterapia psychodynamiczna we Wrocławiu.',
    'slug': '/blog/dlaczego-sama-swiadomosc-nie-wystarcza/',
    'primary': 'dlaczego sama świadomość nie wystarcza',
    'secondary': 'emocjonalne przepracowanie; mechanizmy obronne; psychoterapia psychodynamiczna Wrocław Gaj',
    'h1': '„Wiem, skąd to się bierze, ale nadal tak robię” — dlaczego sama świadomość nie wystarcza?',
    'lead': 'Można trafnie rozumieć własny problem, znać jego historię i mimo to reagować tak samo. Nadal wybierać niedostępne osoby, wycofywać się w chwili bliskości, pracować ponad siły albo zamierać pod wpływem krytyki. Taki rozdźwięk bywa źródłem wstydu: skoro przyczyna jest znana, dlaczego nie następuje zmiana? Psychoterapia psychodynamiczna odpowiada, że wiedza intelektualna i zmiana emocjonalna nie są tym samym. Wgląd jest ważny, lecz musi dotrzeć do tych warstw doświadczenia, które uruchamiają się automatycznie.',
    'sections': [
        ('Rozumieć coś głową, a przeżywać to emocjonalnie', [
            'Człowiek może wiedzieć, że krytyczna uwaga nie oznacza odrzucenia, a mimo to poczuć nagły lęk, złość lub upokorzenie. Dzieje się tak, ponieważ część wiedzy o relacjach ma charakter nie tylko deklaratywny, ale także emocjonalny i proceduralny. Jest zapisana w nawykowym sposobie odczuwania, przewidywania oraz działania.',
            'Taki zapis powstaje często zanim doświadczenie można było nazwać słowami. Późniejsze racjonalne wyjaśnienie nie usuwa go automatycznie. W sytuacji napięcia szybszy okazuje się dawny model: „muszę się wycofać”, „nie wolno mi potrzebować”, „jeśli odmówię, stracę relację”.'
        ]),
        ('Objaw lub schemat ma swoją funkcję', [
            'Zachowanie, które dziś przeszkadza, mogło kiedyś pomagać chronić więź albo zmniejszać przeciążenie. Nadmierne dopasowanie pozwalało unikać konfliktu, perfekcjonizm dawał poczucie kontroli, a emocjonalny dystans zabezpieczał przed rozczarowaniem. Z perspektywy dorosłego życia strategie te bywają kosztowne, lecz psychika nie porzuca ich wyłącznie dlatego, że zostały logicznie ocenione jako niekorzystne.',
            'To również powód, dla którego zalecenie „po prostu zrób inaczej” może nie działać. Reakcja nie jest jedynie złym nawykiem. Wiąże się z przewidywanym niebezpieczeństwem, takim jak utrata akceptacji, zależność, wstyd lub poczucie bezradności.'
        ]),
        ('Mechanizmy obronne nie są wrogiem', [
            'W podejściu psychodynamicznym ważne miejsce zajmują mechanizmy obronne: nieświadome sposoby ograniczania lęku i chronienia obrazu siebie. Mogą przyjmować formę zaprzeczania uczuciom, intelektualizowania, obwiniania siebie, idealizowania drugiej osoby czy odcinania się od potrzeb. Każdy człowiek korzysta z obron; same w sobie nie oznaczają patologii.',
            'Trudność pojawia się, gdy stają się sztywne i zastępują bardziej adekwatny kontakt z rzeczywistością. Co istotne, samo nazwanie obrony nie wystarcza. Zbyt szybkie odbieranie jej mogłoby pozostawić osobę bez dotychczasowego sposobu regulowania napięcia. Terapia pomaga najpierw zrozumieć, przed czym obrona chroni, a następnie rozwijać bezpieczniejsze możliwości reagowania.'
        ]),
        ('Dlaczego zmiana może budzić opór?', [
            'Nawet pożądana zmiana bywa odczuwana jako zagrożenie. Rezygnacja z perfekcjonizmu może uruchomić lęk przed utratą wartości, postawienie granicy — obawę przed samotnością, a przyjęcie pomocy — poczucie zależności. Stary sposób funkcjonowania jest kosztowny, lecz znany. Nowy oznacza wejście w obszar, którego skutków nie można jeszcze przewidzieć.',
            'W terapii opór nie powinien być traktowany jak upór pacjenta ani przeszkoda do przełamania. Jest informacją o konflikcie między pragnieniem zmiany a potrzebą bezpieczeństwa. Jego rozumienie pozwala pracować w tempie, które nie powtarza doświadczenia nacisku i nie odbiera ochrony, zanim pojawią się inne sposoby radzenia sobie.'
        ]),
        ('Na czym polega emocjonalne przepracowanie?', [
            'Przepracowanie nie jest jednym olśnieniem. To wielokrotne rozpoznawanie tego samego wzorca w różnych sytuacjach, zwłaszcza wtedy, gdy towarzyszą mu realne emocje. W relacji terapeutycznej pacjent może na przykład oczekiwać krytyki, choć terapeuta jej nie wyraża, albo unikać złości z obawy, że zagrozi ona kontaktowi. Wspólne badanie tego doświadczenia pozwala połączyć myśl, uczucie i relację.',
            'Nowe doświadczenie nie polega na przekonywaniu, że lęk jest nieracjonalny. Powstaje raczej możliwość pozostania z nim, zrozumienia jego źródła i sprawdzenia, czy przewidywany skutek rzeczywiście następuje. W ten sposób wiedza staje się bardziej osobista i użyteczna.'
        ]),
        ('Jak wygląda zmiana w terapii?', [
            'Zmiana rzadko przebiega liniowo. Najpierw pojawia się zdolność zauważenia reakcji już po fakcie, później w jej trakcie, a dopiero z czasem — przed automatycznym działaniem. Zwiększa się tolerancja niepewności, możliwość nazywania sprzecznych uczuć i wybór między kilkoma sposobami odpowiedzi. Nawrót starego schematu w stresie nie przekreśla procesu; może dostarczyć ważnego materiału do dalszej pracy.',
            'Psychoterapia psychodynamiczna we Wrocławiu, na Gaju, podobnie jak terapia online, opiera się na regularności i relacji, a nie na obietnicy natychmiastowej korekty zachowania. Jej celem jest głębsza zmiana sposobu przeżywania siebie i innych. Świadomość otwiera drzwi, lecz przejście przez nie wymaga czasu, bezpieczeństwa i emocjonalnego doświadczenia.'
        ]),
    ],
    'faq': [
        ('Czy wgląd jest w takim razie niepotrzebny?', 'Jest potrzebny, ponieważ pomaga rozpoznać wzorzec i nadać mu znaczenie. Największą moc zyskuje jednak wtedy, gdy łączy się z emocjami i doświadczeniem relacyjnym.'),
        ('Dlaczego po ważnej sesji problem czasem wraca?', 'Jedna rozmowa może przynieść ulgę, ale utrwalone sposoby reagowania uruchamiają się automatycznie. Powrót schematu nie musi oznaczać porażki; przepracowanie wymaga powtórzeń.'),
        ('Czy terapia psychodynamiczna daje konkretne narzędzia?', 'Jej głównym „narzędziem” jest pogłębione rozumienie i praca w relacji. Efektem mogą być bardzo konkretne zdolności: wcześniejsze rozpoznawanie emocji, stawianie granic i bardziej świadome decyzje.'),
    ],
    'links': [
        ('Artykuł 1', 'Dlaczego ciągle wybieram podobnych partnerów?', 'powtarzające się schematy relacyjne'),
        ('Artykuł 3', 'Co dzieje się między pacjentem a terapeutą?', 'emocjonalne przepracowanie w relacji terapeutycznej'),
        ('Strona usługowa', 'Psychoterapia psychodynamiczna Wrocław – Gaj', 'psychoterapia psychodynamiczna we Wrocławiu na Gaju'),
    ],
},
{
    'number': 3,
    'filename': '03-relacja-terapeutyczna-zrodlo-zmiany.docx',
    'seo_title': 'Relacja terapeutyczna — jak staje się źródłem zmiany?',
    'meta': 'Czym są relacja terapeutyczna, przeniesienie i bezpieczne ramy terapii? Poznaj psychodynamiczne spojrzenie na terapię we Wrocławiu.',
    'slug': '/blog/relacja-terapeutyczna-zrodlo-zmiany/',
    'primary': 'relacja terapeutyczna',
    'secondary': 'przeniesienie w terapii; relacja z psychoterapeutą; psychoterapia psychodynamiczna Wrocław Gaj',
    'h1': 'Co dzieje się między pacjentem a terapeutą? Relacja terapeutyczna jako źródło zmiany',
    'lead': 'Rozmowa w gabinecie może z zewnątrz przypominać każdą inną rozmowę, ale relacja terapeutyczna ma szczególną strukturę i cel. Nie jest przyjaźnią, poradnictwem ani jednostronną analizą pacjenta. W psychoterapii psychodynamicznej stanowi jednocześnie bezpieczne środowisko pracy i źródło informacji o sposobie przeżywania relacji. To, co pojawia się między osobą w terapii a terapeutą — zaufanie, ostrożność, złość, wstyd, idealizacja czy obawa przed oceną — może pomóc zrozumieć wzorce trudne do uchwycenia wyłącznie poprzez opowiadanie o nich.',
    'sections': [
        ('Ramy, które tworzą bezpieczeństwo', [
            'Relacja terapeutyczna opiera się na ustalonych ramach: regularnych spotkaniach, określonym czasie sesji, poufności, zasadach odwoływania wizyt i granicach kontaktu. Te elementy mogą wydawać się techniczne, lecz pełnią ważną funkcję psychologiczną. Przewidywalność pozwala skupić się na doświadczeniu, zamiast stale negocjować warunki relacji.',
            'Bezpieczeństwo nie oznacza braku trudnych emocji. Oznacza raczej, że można je badać bez odwetu, zawstydzania czy wykorzystywania. Terapeuta odpowiada za profesjonalne granice, nie obciąża pacjenta własnymi potrzebami i poddaje pracę refleksji klinicznej, między innymi w superwizji.'
        ]),
        ('Czym jest przeniesienie?', [
            'Przeniesienie to tendencja do przeżywania aktualnej relacji przez pryzmat wcześniejszych doświadczeń, oczekiwań i fantazji. W terapii może pojawić się przekonanie, że terapeuta jest rozczarowany, znudzony, kontrolujący albo wyjątkowo idealny — nawet gdy dostępne fakty nie dają jednoznacznych podstaw do takiej oceny. Nie jest to świadome udawanie ani błąd, który należy szybko skorygować.',
            'Podobne procesy występują w codziennych relacjach. Gabinet pozwala jednak obserwować je uważniej. Pytanie nie brzmi wyłącznie: „Czy ta ocena jest prawdziwa?”, lecz także: „Co sprawia, że właśnie takie znaczenie pojawia się teraz i jak wpływa na kontakt?”.'
        ]),
        ('Terapeuta nie jest pustym ekranem', [
            'Relacja terapeutyczna jest realna. Terapeuta ma własny styl, popełnia pomyłki i wpływa na przebieg spotkania. Podejście psychodynamiczne nie zakłada, że każda reakcja pacjenta pochodzi wyłącznie z przeszłości. Dlatego interpretacja przeniesienia powinna uwzględniać rzeczywisty kontekst, a nie unieważniać odczuć osoby w terapii.',
            'Terapeuta obserwuje również własne reakcje emocjonalne, określane w szerszym sensie jako przeciwprzeniesienie. Po poddaniu refleksji mogą one pomóc rozumieć to, co dzieje się w kontakcie. Nie oznacza to dowolnego dzielenia się uczuciami; są one przede wszystkim materiałem do odpowiedzialnego namysłu klinicznego.'
        ]),
        ('Czy terapeuta powinien doradzać?', [
            'Psychoterapia psychodynamiczna zwykle nie polega na podejmowaniu decyzji za pacjenta. Szybka rada mogłaby przynieść chwilową ulgę, ale również pominąć konflikt, znaczenie wyboru i zdolność osoby w terapii do samodzielnego myślenia. Terapeuta częściej pomaga rozpoznać uczucia, konsekwencje oraz nieświadome oczekiwania związane z dostępnymi możliwościami.',
            'Nie oznacza to chłodnego milczenia ani zakazu udzielania informacji. Sposób pracy zależy od sytuacji, stanu pacjenta i celu terapii. W kryzysie bezpieczeństwo może wymagać bardziej bezpośredniego działania. W zwykłym procesie ważniejsze od gotowej odpowiedzi bywa rozwijanie wewnętrznej zdolności do dokonywania wyborów.'
        ]),
        ('Pęknięcie i naprawa relacji', [
            'W każdej ważnej relacji zdarzają się nieporozumienia. Pacjent może poczuć się pominięty, źle zrozumiany lub zirytowany sposobem wypowiedzi terapeuty. Taki moment nie musi oznaczać, że terapia przestała działać. Jeśli zostanie zauważony i omówiony, może stać się doświadczeniem szczególnie wartościowym.',
            'Dla osoby, która wcześniej musiała przemilczać złość albo zakładała, że konflikt kończy więź, możliwość nazwania rozczarowania i pozostania w kontakcie tworzy nowy rodzaj doświadczenia. Naprawa nie polega na przekonaniu pacjenta, że terapeuta miał rację. Wymaga ciekawości obu stron, uznania wpływu sytuacji i gotowości terapeuty do przyjęcia odpowiedzialności za własny udział.'
        ]),
        ('Relacja jako miejsce zmiany, nie cel sam w sobie', [
            'Dobra więź terapeutyczna nie musi oznaczać stałej sympatii ani pełnej zgody. Powinna umożliwiać szczerość, refleksję i stopniowe podejmowanie tematów, które wcześniej były zbyt zagrażające. Z czasem osoba w terapii może lepiej rozpoznawać własne potrzeby, sprawdzać interpretacje zamiast uznawać je za fakty oraz doświadczać bliskości bez automatycznego wycofania lub podporządkowania.',
            'Psychoterapia psychodynamiczna we Wrocławiu, na Gaju, lub online zachowuje te same podstawowe zasady: poufność, stabilne ramy i refleksję nad relacją. Jej jakość nie wynika z obietnicy idealnego kontaktu, lecz ze zdolności do rozumienia także tego, co niewygodne. Relacja terapeutyczna staje się źródłem zmiany wtedy, gdy można w niej nie tylko mówić o własnych wzorcach, ale również bezpiecznie je zauważać i przekształcać.'
        ]),
    ],
    'faq': [
        ('Czy przywiązanie do terapeuty jest czymś niewłaściwym?', 'Nie. Uczucia wobec terapeuty są naturalną częścią znaczącej, regularnej relacji. Ważne jest, aby mogły zostać omówione przy zachowaniu profesjonalnych granic.'),
        ('Czy można powiedzieć terapeucie o złości lub rozczarowaniu?', 'Tak. Rozmowa o trudnych reakcjach może dostarczyć ważnych informacji i pomóc naprawić nieporozumienie. Terapeuta powinien przyjąć taki temat z ciekawością, a nie odwetem.'),
        ('Po czym poznać bezpieczne ramy terapii?', 'Zasady są jasne, poufność omówiona, a granice konsekwentne. Terapeuta nie wykorzystuje relacji do zaspokajania własnych potrzeb i jest otwarty na pytania dotyczące sposobu pracy.'),
    ],
    'links': [
        ('Artykuł 2', 'Dlaczego sama świadomość problemu nie wystarcza?', 'emocjonalne przepracowanie'),
        ('Artykuł 4', 'Czy przeszłość naprawdę ma aż takie znaczenie?', 'wpływ wcześniejszych relacji na teraźniejszość'),
        ('Strona usługowa', 'Psychoterapia psychodynamiczna Wrocław – Gaj', 'psychoterapia psychodynamiczna we Wrocławiu na Gaju'),
    ],
},
{
    'number': 4,
    'filename': '04-czy-przeszlosc-ma-znaczenie.docx',
    'seo_title': 'Czy przeszłość wpływa na dorosłe życie i relacje?',
    'meta': 'Jak wcześniejsze doświadczenia wpływają na emocje i związki? Psychoterapia psychodynamiczna we Wrocławiu bada ich znaczenie dla teraźniejszości.',
    'slug': '/blog/czy-przeszlosc-wplywa-na-dorosle-zycie/',
    'primary': 'czy przeszłość wpływa na dorosłe życie',
    'secondary': 'wpływ dzieciństwa na relacje; wczesne doświadczenia; psychoterapia psychodynamiczna Wrocław Gaj',
    'h1': 'Czy przeszłość naprawdę ma aż takie znaczenie?',
    'lead': 'Psychoterapia psychodynamiczna bywa kojarzona z niekończącym się powracaniem do dzieciństwa. To uproszczenie. Przeszłość ma znaczenie nie dlatego, że wyjaśnia wszystko ani dlatego, że terapeuta szuka winnych. Jest ważna wtedy, gdy pozostaje aktywna w teraźniejszości: w sposobie regulowania emocji, tworzenia bliskości, traktowania własnych potrzeb i przewidywania reakcji innych. Celem nie jest rekonstrukcja idealnie dokładnej biografii, ale rozpoznanie, które dawne doświadczenia nadal nadają sens obecnym sytuacjom i ograniczają swobodę wyboru.',
    'sections': [
        ('Pierwsze relacje uczą, czego oczekiwać', [
            'Dziecko rozwija się w zależności od innych. W codziennym kontakcie uczy się, czy sygnały zmęczenia, lęku lub złości spotykają się z odpowiedzią, czy bliskość jest przewidywalna oraz czy można pozostać sobą bez ryzyka utraty więzi. Z tysięcy takich doświadczeń powstają wewnętrzne oczekiwania dotyczące siebie i ludzi.',
            'Nie chodzi o pojedynczą sytuację ani o „idealne” rodzicielstwo. Znaczenie mają powtarzalne wzorce, temperament dziecka, możliwości opiekunów i szerszy kontekst życia. Ta sama okoliczność może mieć inne znaczenie dla różnych osób, dlatego terapia nie korzysta z prostego słownika: jedno wydarzenie nie prowadzi automatycznie do jednego problemu.'
        ]),
        ('Pamięć działa także bez opowieści', [
            'Nie wszystkie ważne doświadczenia są dostępne jako wyraźne wspomnienia. Część utrwala się jako pamięć utajona: napięcie ciała, automatyczne oczekiwanie zagrożenia, trudność z przyjmowaniem pomocy albo przekonanie odczuwane jako oczywistość. Można nie pamiętać konkretnych scen, a jednocześnie reagować według reguł ukształtowanych w dawnych relacjach.',
            'Dlatego brak wspomnień z dzieciństwa nie uniemożliwia psychoterapii. Punktem wyjścia może być teraźniejszość: sytuacje wywołujące nieproporcjonalnie silne emocje, powtarzające się konflikty, sny, fantazje, uniki oraz sposób przeżywania relacji terapeutycznej.'
        ]),
        ('Jak przeszłość pojawia się w teraźniejszości?', [
            'Wpływ historii często staje się widoczny w drobnych, powtarzalnych momentach. Osoba może długo przygotowywać się do prośby, ponieważ spodziewa się odmowy; nadmiernie wyjaśniać swoje decyzje, aby uniknąć krytyki; albo tracić kontakt z własną złością, gdy ważna relacja staje się napięta. Reakcje te nie są dowodem na określoną przeszłość, lecz wskazówką do wspólnego badania.',
            'Terapeuta interesuje się zarówno podobieństwem do dawnych sytuacji, jak i różnicą. Uczy to odróżniać pamięć emocjonalną od aktualnych faktów. Z czasem możliwe staje się rozpoznanie: „to uczucie jest realne, ale jego siła i znaczenie mogą należeć także do wcześniejszego doświadczenia”.'
        ]),
        ('Przeszłość nie jest jedynym wyjaśnieniem', [
            'Na zdrowie psychiczne wpływają również predyspozycje biologiczne, aktualne relacje, praca, sytuacja ekonomiczna, choroby, doświadczenia dyskryminacji czy nagłe kryzysy. Koncentracja wyłącznie na dzieciństwie mogłaby przesłonić realne problemy obecnego życia. Rzetelna praca psychodynamiczna uwzględnia oba wymiary: historię oraz to, co dzieje się teraz.',
            'Nie każda trudność jest ukrytym konfliktem. Czasem lęk stanowi zrozumiałą reakcję na brak bezpieczeństwa, a wyczerpanie wynika z przeciążających warunków. Zadaniem terapeuty nie jest psychologizowanie wszystkiego, lecz wspólne różnicowanie źródeł cierpienia.'
        ]),
        ('Rozumienie historii nie służy oskarżaniu', [
            'Badanie dzieciństwa może uruchamiać obawę, że terapia będzie polegała na obwinianiu rodziców. Tymczasem uznanie wpływu wcześniejszych relacji nie wymaga wydawania prostych wyroków. Opiekunowie sami działali w określonych warunkach i z własnymi ograniczeniami. Zrozumienie kontekstu nie powinno jednak unieważniać bólu ani zmuszać do przedwczesnego usprawiedliwienia.',
            'Dojrzała perspektywa mieści ambiwalencję: wdzięczność i złość, miłość i rozczarowanie, dobre intencje i realne konsekwencje. Terapia pomaga tworzyć bardziej złożoną opowieść, w której odpowiedzialność za dzisiejsze życie nie oznacza zaprzeczania temu, co wcześniej je ukształtowało.'
        ]),
        ('Po co wracać do tego, czego nie można zmienić?', [
            'Przeszłych wydarzeń nie da się cofnąć, można jednak zmienić ich miejsce w psychice. To, co dotąd wracało jako bezimienny lęk, wstyd albo przymus powtarzania, może zostać nazwane, przeżyte i połączone z historią. Dzięki temu dawne reguły przestają być traktowane jak niepodważalne fakty o świecie.',
            'Psychoterapia psychodynamiczna we Wrocławiu, na Gaju, lub online nie powinna zatrzymywać osoby w przeszłości. Jej zadaniem jest zwiększenie swobody w teraźniejszości: możliwość budowania innych relacji, łagodniejszego traktowania siebie i bardziej adekwatnego reagowania na bieżące sytuacje. Przeszłość ma znaczenie, ale nie jest przeznaczeniem. Właśnie dlatego warto ją rozumieć — aby nie musiała nieświadomie decydować o przyszłości.'
        ]),
    ],
    'faq': [
        ('Czy psychoterapia psychodynamiczna zawsze skupia się na dzieciństwie?', 'Nie. Historia jest badana w związku z aktualnymi trudnościami. Dużo uwagi poświęca się bieżącym emocjom, relacjom i temu, co dzieje się podczas sesji.'),
        ('Co, jeśli prawie nie ma wspomnień z wczesnych lat?', 'Dokładne wspomnienia nie są warunkiem terapii. Materiałem do pracy pozostają obecne reakcje, wzorce relacyjne, uczucia, fantazje i sposób przeżywania kontaktu.'),
        ('Czy zrozumienie przeszłości zmienia teraźniejszość?', 'Może ją zmieniać, jeśli nie pozostaje wyłącznie wyjaśnieniem intelektualnym. Znaczenie ma emocjonalne przepracowanie oraz rozwijanie nowych sposobów bycia w relacji.'),
    ],
    'links': [
        ('Artykuł 1', 'Dlaczego ciągle wybieram podobnych partnerów?', 'wpływ dawnych wzorców na wybór partnera'),
        ('Artykuł 2', 'Dlaczego sama świadomość problemu nie wystarcza?', 'różnica między rozumieniem a przepracowaniem'),
        ('Strona usługowa', 'Psychoterapia psychodynamiczna Wrocław – Gaj', 'psychoterapia psychodynamiczna we Wrocławiu na Gaju'),
    ],
},
]

NAVY = '17324D'
TEAL = '2C7A78'
PALE = 'EAF2F3'
LIGHT = 'F4F6F8'
MID = '667785'
DARK = '1E2933'
WHITE = 'FFFFFF'
BORDER = 'D5DEE5'


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_margins(cell, top=120, start=160, bottom=120, end=160):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        if edge in kwargs:
            edge_data = kwargs.get(edge)
            tag = 'start' if edge == 'left' else 'end' if edge == 'right' else edge
            tag = f'w:{tag}'
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key in ['val', 'sz', 'space', 'color']:
                if key in edge_data:
                    element.set(qn(f'w:{key}'), str(edge_data[key]))


def add_field_row(table, label, value, shade=False):
    cells = table.add_row().cells
    cells[0].width = Cm(4.1)
    cells[1].width = Cm(12.1)
    for cell in cells:
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_border(cell,
                        bottom={'val': 'single', 'sz': 5, 'color': BORDER},
                        top={'val': 'single', 'sz': 5, 'color': BORDER},
                        left={'val': 'single', 'sz': 5, 'color': BORDER},
                        right={'val': 'single', 'sz': 5, 'color': BORDER})
        if shade:
            set_cell_shading(cell, LIGHT)
    p = cells[0].paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(label.upper())
    r.bold = True
    r.font.name = 'Aptos'
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor.from_string(TEAL)
    p = cells[1].paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(value)
    r.font.name = 'Aptos'
    r.font.size = Pt(9.5)
    r.font.color.rgb = RGBColor.from_string(DARK)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run('STRONA ')
    run.font.name = 'Aptos'
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string(MID)
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = 'PAGE'
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)


def add_rule(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(10)
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '14')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), TEAL)
    pbdr.append(bottom)
    pPr.append(pbdr)


def publication_word_count(a):
    pieces = [a['h1'], a['lead']]
    for h, paras in a['sections']:
        pieces.append(h)
        pieces.extend(paras)
    pieces.append('Najczęściej zadawane pytania')
    for q, ans in a['faq']:
        pieces.extend([q, ans])
    return len(re.findall(r"\b[\wÀ-ž„”’'-]+\b", ' '.join(pieces), re.UNICODE))


def configure_styles(doc):
    styles = doc.styles
    normal = styles['Normal']
    normal.font.name = 'Aptos'
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor.from_string(DARK)
    normal.paragraph_format.line_spacing = 1.16
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.widow_control = True

    h1 = styles['Title']
    h1.font.name = 'Aptos Display'
    h1.font.size = Pt(26)
    h1.font.bold = True
    h1.font.color.rgb = RGBColor.from_string(NAVY)
    h1.paragraph_format.space_after = Pt(10)

    for style_name, size, color, before, after in [
        ('Heading 1', 20, NAVY, 8, 8),
        ('Heading 2', 14.5, NAVY, 16, 6),
        ('Heading 3', 11, TEAL, 10, 3),
    ]:
        s = styles[style_name]
        s.font.name = 'Aptos Display'
        s.font.size = Pt(size)
        s.font.bold = True
        s.font.color.rgb = RGBColor.from_string(color)
        s.paragraph_format.space_before = Pt(before)
        s.paragraph_format.space_after = Pt(after)
        s.paragraph_format.keep_with_next = True


def create_doc(a):
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(1.75)
    section.bottom_margin = Cm(1.7)
    section.left_margin = Cm(2.15)
    section.right_margin = Cm(2.15)

    configure_styles(doc)

    # Header
    header = section.header
    header.is_linked_to_previous = False
    hp = header.paragraphs[0]
    hp.paragraph_format.space_after = Pt(0)
    r = hp.add_run('PSYCHOTERAPIA PSYCHODYNAMICZNA')
    r.font.name = 'Aptos'
    r.font.size = Pt(8)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string(TEAL)
    r2 = hp.add_run(f'   •   PAKIET SEO   •   {a["number"]}/4')
    r2.font.name = 'Aptos'
    r2.font.size = Pt(8)
    r2.font.color.rgb = RGBColor.from_string(MID)
    pPr = hp._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '6')
    bottom.set(qn('w:space'), '5')
    bottom.set(qn('w:color'), BORDER)
    pbdr.append(bottom)
    pPr.append(pbdr)

    # Footer
    fp = section.footer.paragraphs[0]
    add_page_number(fp)

    kicker = doc.add_paragraph()
    kicker.paragraph_format.space_before = Pt(8)
    kicker.paragraph_format.space_after = Pt(6)
    r = kicker.add_run('ARTYKUŁ EKSPERCKI  /  MATERIAŁ DO PUBLIKACJI')
    r.font.name = 'Aptos'
    r.font.size = Pt(8.5)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string(TEAL)

    title = doc.add_paragraph(style='Title')
    title.add_run(a['h1'])

    sub = doc.add_paragraph()
    sub.paragraph_format.space_after = Pt(14)
    r = sub.add_run(f"Psychoterapia indywidualna dorosłych  •  SEO lokalne: Wrocław • Gaj  •  {publication_word_count(a)} słów publikacyjnych")
    r.font.name = 'Aptos'
    r.font.size = Pt(9.5)
    r.font.color.rgb = RGBColor.from_string(MID)

    doc.add_heading('Dane SEO', level=2)
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    add_field_row(table, 'Tytuł SEO', a['seo_title'], True)
    add_field_row(table, 'Meta description', a['meta'], False)
    add_field_row(table, 'Slug', a['slug'], True)
    add_field_row(table, 'Fraza główna', a['primary'], False)
    add_field_row(table, 'Frazy wspierające', a['secondary'], True)

    doc.add_paragraph()
    add_rule(doc)

    label = doc.add_paragraph()
    label.paragraph_format.space_after = Pt(7)
    r = label.add_run('TREŚĆ DO PUBLIKACJI')
    r.font.name = 'Aptos'
    r.font.size = Pt(8.5)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string(TEAL)

    doc.add_heading(a['h1'], level=1)

    lead_table = doc.add_table(rows=1, cols=1)
    lead_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = lead_table.cell(0, 0)
    set_cell_shading(cell, PALE)
    set_cell_margins(cell, top=180, start=220, bottom=180, end=220)
    set_cell_border(cell, left={'val': 'single', 'sz': 18, 'color': TEAL})
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.14
    r = p.add_run(a['lead'])
    r.font.name = 'Aptos'
    r.font.size = Pt(11)
    r.font.italic = True
    r.font.color.rgb = RGBColor.from_string(NAVY)

    for heading, paragraphs in a['sections']:
        doc.add_heading(heading, level=2)
        for text in paragraphs:
            p = doc.add_paragraph(text)
            p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    doc.add_heading('Najczęściej zadawane pytania', level=2)
    for question, answer in a['faq']:
        doc.add_heading(question, level=3)
        p = doc.add_paragraph(answer)
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # Editorial section
    doc.add_page_break()
    label = doc.add_paragraph()
    label.paragraph_format.space_before = Pt(6)
    label.paragraph_format.space_after = Pt(5)
    r = label.add_run('NOTATKI REDAKCYJNE')
    r.font.name = 'Aptos'
    r.font.size = Pt(8.5)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string(TEAL)
    doc.add_heading('Propozycje linkowania wewnętrznego', level=1)
    intro = doc.add_paragraph('Linki warto umieszczać kontekstowo, jeden raz na naturalnie brzmiącą frazę. Poniższe propozycje nie są częścią tekstu artykułu.')
    intro.paragraph_format.space_after = Pt(12)

    link_table = doc.add_table(rows=1, cols=3)
    link_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    link_table.autofit = False
    headers = ['Cel linku', 'Docelowa treść', 'Sugerowany anchor']
    for idx, txt in enumerate(headers):
        cell = link_table.rows[0].cells[idx]
        set_cell_shading(cell, NAVY)
        set_cell_margins(cell)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(txt.upper())
        r.bold = True
        r.font.name = 'Aptos'
        r.font.size = Pt(8)
        r.font.color.rgb = RGBColor.from_string(WHITE)
    for row_idx, (kind, target, anchor) in enumerate(a['links']):
        cells = link_table.add_row().cells
        for cell in cells:
            set_cell_margins(cell)
            set_cell_border(cell,
                            bottom={'val': 'single', 'sz': 5, 'color': BORDER},
                            left={'val': 'single', 'sz': 5, 'color': BORDER},
                            right={'val': 'single', 'sz': 5, 'color': BORDER})
            if row_idx % 2 == 1:
                set_cell_shading(cell, LIGHT)
        vals = [kind, target, anchor]
        for i, val in enumerate(vals):
            p = cells[i].paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(val)
            r.font.name = 'Aptos'
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor.from_string(DARK)
            if i == 0:
                r.bold = True
                r.font.color.rgb = RGBColor.from_string(TEAL)

    doc.add_heading('Wskazówki publikacyjne', level=2)
    tips = [
        'Ustawić tytuł artykułu jako jedyny nagłówek H1; śródtytuły jako H2, a pytania FAQ jako H3.',
        'Dodać link do strony usługowej dopiero po opublikowaniu właściwego adresu URL; unikać powtarzania tej samej frazy w każdym akapicie.',
        'Uzupełnić dane strukturalne Article; FAQ oznaczyć semantycznie, bez gwarantowania rozszerzonego wyniku w wyszukiwarce.',
        'Zachować spójny zapis lokalizacji: „Wrocław”, „Gaj” oraz naturalną formę „we Wrocławiu na Gaju” na wszystkich podstronach gabinetu.',
    ]
    for tip in tips:
        p = doc.add_paragraph(style='List Bullet')
        p.add_run(tip)

    note_table = doc.add_table(rows=1, cols=1)
    note_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = note_table.cell(0, 0)
    set_cell_shading(cell, LIGHT)
    set_cell_margins(cell, top=150, start=180, bottom=150, end=180)
    set_cell_border(cell, top={'val': 'single', 'sz': 6, 'color': BORDER},
                    bottom={'val': 'single', 'sz': 6, 'color': BORDER},
                    left={'val': 'single', 'sz': 6, 'color': BORDER},
                    right={'val': 'single', 'sz': 6, 'color': BORDER})
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run('Nota etyczna  ')
    r.bold = True
    r.font.name = 'Aptos'
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor.from_string(TEAL)
    r = p.add_run('Tekst ma charakter psychoedukacyjny. Nie służy do stawiania diagnozy i nie zastępuje indywidualnej konsultacji ze specjalistą.')
    r.font.name = 'Aptos'
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor.from_string(DARK)

    # Document properties
    props = doc.core_properties
    props.title = a['h1']
    props.subject = 'Artykuł psychoedukacyjny i pakiet SEO — psychoterapia psychodynamiczna'
    props.keywords = f"{a['primary']}; {a['secondary']}"
    props.comments = 'Materiał przygotowany do publikacji na stronie internetowej.'

    path = OUT / a['filename']
    doc.save(path)
    return path


if __name__ == '__main__':
    for article in articles:
        print(article['number'], publication_word_count(article), article['seo_title'], len(article['seo_title']), len(article['meta']))
        path = create_doc(article)
        print('saved', path)
